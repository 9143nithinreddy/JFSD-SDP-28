package com.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ReturnBookServlet
 */
@WebServlet("/ReturnBookServlet")
public class ReturnBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try {
            int bookId = Integer.parseInt(request.getParameter("id"));

            String dbURL = "jdbc:mysql://localhost:3306/jfsd-ps46";
            String dbUser = "root";
            String dbPassword = "12345";

            out.println("Connecting to database...");
            
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPassword)) {
                String sql = "DELETE FROM user_books WHERE book_id = ?";
                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setInt(1, bookId);

                int rowsDeleted = statement.executeUpdate();
                out.println("Rows deleted: " + rowsDeleted);

                if (rowsDeleted > 0) {
                    response.sendRedirect("mybooks.jsp");
                } else {
                    out.println("Failed to return the book.");
                }
            } catch (SQLException e) {
                e.printStackTrace(out); // Print SQL errors to the page for now
            }

        } catch (Exception e) {
            e.printStackTrace(out); // Print other errors to the page for now
        }
    }
}
